<div id="navbar">
    <ul> <!-- code for nav bar works nicely here-->
            <li class="logo"><img src="/img/logo_ZombieRun.png" alt="ZombieRunLogo"></li>
            <li> <a href="index.html">Home</a> </li>
            <li> <a href="about.html">About</a> </li>
            <li> <a href="contact.html">Contact</a> </li>
            <li> <a href="login.html">SignUp / Login</a> </li>   <!-- Signup login page is same page use php script to detect if logged in, if true logout 
                                                                    if false display login, with link to signup php script
                                                                    PHP script used to detect if signed in if true this link is displayed -->

            <li> <a href="userProfile.html"> Profile </a> </li> 
    </ul> 
</div>