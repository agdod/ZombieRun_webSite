<?php include ('navbar.php') ?>
<!DOCTYPE html>
<html>
    <head>
        <title>ZombieRun</title>
        <link rel="stylesheet" type="text/css" href="/css/main.css">
    </head>

    <body>
        
        <h1>ZombieRun</h1>
        <!--- navbar / header will be its own php file which is then including in each page-->
        <!-- enabling one nav bar to be displayed on all pages changes only then need to be made to one file for navigation-->
        
            <!-- end of temp demo for nav bar--> 
        
        <!-- same nav bar code here doesnt display in grid box one displays at top and behind main grid box three-->
        <div id="layout">
                   <div id="one"></div> 
                   <div id ="two"> LOGIN / SIGNUP </div>
                   <div id="three">MAIN</div>
                   <div id ="four">ADS</div>
                   <div id="five">EXTRA</div>
                   <div id="six">LINKS</div>
                   <div id="seven">FOOTER</div>
        </div>
        
        <blockquote>
                <p>"Run the gaulet of zombies, escape, survive, <B>RUN!</B>"</p>
        </blockquote>
        
            
      <!-- footer same as nav bar-->  
    </body>
</html>